#tictactoe package

#

Summary of the package
This is my first Tic Tac Toe game.

I have been practicing coding for a year now. This game is a mix of understanding many different tutorials to develop my own understanding and application. 

Feel free to fork the project / comment your thoughts. 

#Files
license.txt - outlines the licensing terms of using this software
game.py - code for TicTacToe game
__init__.py - initiates the program to play the game

