This is my first Tic Tac Toe game.

I have been practicing coding for a year now. This game is a mix of understanding many different tutorials to develop my own understanding and application. 

Feel free to fork the project / comment your thoughts. 