# TODO: Fill out this file with information about your package

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/

from setuptools import setup

setup(name='tictactoe_pkesarkar',
      version='0.1',
      description='its a game',
      packages=['tictactoe'],
      author= 'Punith Kesarkar',
      author_email = 'punith.kesarkar@gmail.com',
      zip_safe=False)